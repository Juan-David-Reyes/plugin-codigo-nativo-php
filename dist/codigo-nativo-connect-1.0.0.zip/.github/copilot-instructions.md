# Código Nativo HUB Plugin - AI Coding Guidelines

## Project Overview
This is a WordPress plugin that provides API connectivity between WordPress sites and the Código Nativo dashboard panel. The plugin exposes REST endpoints for site status monitoring and log submission.

## Architecture
- **Main Plugin File**: `codigo-nativo.php` - Contains plugin header and includes `includes/api.php` and `includes/admin.php`
- **API Layer**: `includes/api.php` - Handles REST API registration, authentication, and endpoints
- **Admin Interface**: `includes/admin.php` - Provides settings page for token management
- **No Database Schema**: Uses WordPress options for configuration storage

## Key Patterns & Conventions

### Function Naming
Prefix all functions with `cn_` (e.g., `cn_check_auth`, `cn_get_site_status`, `cn_send_logs`)

### Security Practices
- Always include `if (!defined('ABSPATH')) exit;` at the top of PHP files
- Use WordPress permission callbacks for API authentication
- Hash tokens with `wp_hash_password` and verify with `wp_check_password`
- Enforce HTTPS for all API requests
- Implement rate limiting using WordPress transients
- Log failed authentication attempts
- Sanitize all inputs with `sanitize_text_field`
- Use nonces for admin forms to prevent CSRF

### API Design
- REST namespace: `codigonativo/v1`
- Authentication: Bearer token via `Authorization` header with expiration
- Token storage: WordPress options `cn_api_token_hash` and `cn_api_token_expiration`
- Endpoints:
  - `GET /wp-json/codigonativo/v1/status` - Returns site status
  - `POST /wp-json/codigonativo/v1/logs` - Accepts log data
- Return `WP_REST_Response` for success, `WP_Error` for failures

### WordPress Integration
- Register REST routes in `rest_api_init` hook
- Use `get_option()` and `update_option()` for configuration
- Add admin menu with `add_menu_page`
- Use transients for temporary data (rate limiting)
- Follow WordPress coding standards

## Development Workflow
- No build process required - pure PHP
- Activate plugin in WordPress admin to test
- Configure token via admin panel
- API endpoints testable via curl with Bearer auth
- Check logs in WordPress debug.log for errors

## File Structure
- Place API logic in `includes/api.php`
- Admin interface in `includes/admin.php`
- Main plugin file handles initialization only
- Use `plugin_dir_path(__FILE__)` for include paths

## Common Tasks
- Adding new endpoints: Register in `rest_api_init` hook with auth callback
- Storing config: Use `update_option()` for persistent settings
- Error handling: Return WP_Error objects from API callbacks
- Admin settings: Add fields to `cn_settings_page` function
- Security: Always validate inputs and check permissions